var searchData=
[
  ['size_38',['size',['../classstack.html#a926a597bae913d1bf4772be35c14b71e',1,'stack']]]
];
