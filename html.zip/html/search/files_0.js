var searchData=
[
  ['logicass2_2ecpp_21',['logicass2.cpp',['../logicass2_8cpp.html',1,'']]]
];
