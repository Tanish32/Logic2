var searchData=
[
  ['getelements_2',['getElements',['../logicass2_8cpp.html#a14598a8a47197f8a0c793d94acd8e318',1,'logicass2.cpp']]]
];
