var searchData=
[
  ['size_16',['size',['../classstack.html#a926a597bae913d1bf4772be35c14b71e',1,'stack']]],
  ['stack_17',['stack',['../classstack.html',1,'stack'],['../classstack.html#acd90ca289a90d074a7597503e876d3ae',1,'stack::stack()']]]
];
