var searchData=
[
  ['isempty_24',['isEmpty',['../classstack.html#adc343daa5cd8aaab473af868ab44302b',1,'stack']]],
  ['isfull_25',['isFull',['../classstack.html#a81e440f7bf1aef3847255be5aa437f5a',1,'stack']]]
];
