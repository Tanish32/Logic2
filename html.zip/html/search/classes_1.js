var searchData=
[
  ['stack_20',['stack',['../classstack.html',1,'']]]
];
