var searchData=
[
  ['arr_0',['arr',['../classstack.html#a6687b2fde43600e5361126cc915721d5',1,'stack']]]
];
