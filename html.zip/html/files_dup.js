var files_dup =
[
    [ "logicass2.cpp", "logicass2_8cpp.html", "logicass2_8cpp" ]
];